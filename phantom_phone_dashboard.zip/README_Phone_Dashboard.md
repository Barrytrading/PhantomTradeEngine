
# Phantom Trade Engine — Phone Dashboard

This folder contains a **ready-to-deploy phone-friendly dashboard** for your GitHub repo **Barrytrading/PhantomTradeEngine**.

## Files
- `docs/index.html` — main dashboard (GitHub Pages entry)
- `docs/app.js` — loads CSV files from `/data` in this repo
- `docs/styles.css` — mobile-first styling
- `data/portfolio_value.csv` — daily portfolio values (`date,value`)
- `data/trades_log.csv` — trade history (`date,symbol,side,qty,entry,exit,pl`)

## How to Deploy (GitHub Pages)
1. Push the `docs/` and `data/` folders to your repo.
2. On GitHub, open **Settings → Pages**.
3. Under **Build and deployment**:
   - Source: **Deploy from a branch**
   - Branch: **main** and **/docs** folder
4. Save. Your site will be available at:  
   `https://Barrytrading.github.io/PhantomTradeEngine/`

The dashboard automatically loads data from:
- `https://raw.githubusercontent.com/Barrytrading/PhantomTradeEngine/main/data/portfolio_value.csv`
- `https://raw.githubusercontent.com/Barrytrading/PhantomTradeEngine/main/data/trades_log.csv`

## Updating Data
- Append a new line to `data/portfolio_value.csv` each day: `YYYY-MM-DD,<number>`
- Add rows to `data/trades_log.csv` for each completed trade.

You can do this directly on GitHub (Add file → Edit) from your phone.
